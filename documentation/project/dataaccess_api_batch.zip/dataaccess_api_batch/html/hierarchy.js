var hierarchy =
[
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.dto.BatchDto", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html", null ],
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.querystores.batchtlqueries.BatchSampleQuery", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1querystores_1_1batchtlqueries_1_1BatchSampleQuery.html", null ],
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.dto.BatchShortDto", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html", null ],
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.querystores.batchtlqueries.BatchTlQuery", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1querystores_1_1batchtlqueries_1_1BatchTlQuery.html", null ],
    [ "Exception", null, [
      [ "com.teresol.dataaccess.api.dataaccess_api_batch.exceptions.ListNotEqualException", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1exceptions_1_1ListNotEqualException.html", null ]
    ] ],
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.services.MainBatchService", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1services_1_1MainBatchService.html", null ],
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.web.MainResource", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1web_1_1MainResource.html", null ],
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.connection.PasswordDecrypter", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1connection_1_1PasswordDecrypter.html", null ],
    [ "com.teresol.dataaccess.api.dataaccess_api_batch.util.Utility", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1util_1_1Utility.html", null ],
    [ "CredentialsProvider", null, [
      [ "com.teresol.dataaccess.api.dataaccess_api_batch.connection.Box2CredentialProvider", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1connection_1_1Box2CredentialProvider.html", null ]
    ] ]
];