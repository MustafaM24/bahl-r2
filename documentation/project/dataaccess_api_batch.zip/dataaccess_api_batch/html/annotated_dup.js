var annotated_dup =
[
    [ "com", null, [
      [ "teresol", null, [
        [ "dataaccess", null, [
          [ "api", null, [
            [ "dataaccess_api_batch", null, [
              [ "connection", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1connection.html", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1connection" ],
              [ "dto", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto.html", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto" ],
              [ "exceptions", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1exceptions.html", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1exceptions" ],
              [ "querystores", null, [
                [ "batchtlqueries", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1querystores_1_1batchtlqueries.html", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1querystores_1_1batchtlqueries" ]
              ] ],
              [ "services", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1services.html", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1services" ],
              [ "util", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1util.html", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1util" ],
              [ "web", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1web.html", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1web" ]
            ] ]
          ] ]
        ] ]
      ] ]
    ] ]
];