var namespaces_dup =
[
    [ "com", null, [
      [ "teresol", null, [
        [ "dataaccess", null, [
          [ "api", null, [
            [ "dataaccess_api_batch", null, [
              [ "connection", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1connection.html", null ],
              [ "dto", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto.html", null ],
              [ "exceptions", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1exceptions.html", null ],
              [ "querystores", null, [
                [ "batchtlqueries", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1querystores_1_1batchtlqueries.html", null ]
              ] ],
              [ "services", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1services.html", null ],
              [ "util", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1util.html", null ],
              [ "web", "namespacecom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1web.html", null ]
            ] ]
          ] ]
        ] ]
      ] ]
    ] ]
];