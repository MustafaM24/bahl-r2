var classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto =
[
    [ "BatchShortDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a00e68449cce81bd68a049312a6329490", null ],
    [ "BatchShortDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#add15a8dcb0b2d39ceb5e1b6c33fa489e", null ],
    [ "columns", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a700f501e1415292b3cc02882b6f91903", null ],
    [ "getinputColumn", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a72b6e143ca0c509577b2b1f873134c24", null ],
    [ "getinputColumnValue", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#ac4a12321bcde6f29a41e1832da2e9928", null ],
    [ "getOutputList", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#ac0a2b6ac4a4fb73f1cdc57a43f544e70", null ],
    [ "setinputColumn", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a7b3b489230600be1a2d75b553ee72ef5", null ],
    [ "setinputColumnValue", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#aeadda37bda550d4520a28515a48266a5", null ],
    [ "setOutputList", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a82129e342b4ae6a7b69ac1658915b568", null ],
    [ "values", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a53f00f2bf9e79346b89e3a4afe83ea56", null ]
];