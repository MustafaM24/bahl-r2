var namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1util =
[
    [ "Utility", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1util_1_1Utility.html", null ]
];