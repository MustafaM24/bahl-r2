var classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1exceptions_1_1BatchExceptions =
[
    [ "BatchExceptions", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1exceptions_1_1BatchExceptions.html#aab5a7f63fb9138afb71d5c927f96e7d8", null ]
];