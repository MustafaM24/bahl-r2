var classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web_1_1MainResource =
[
    [ "get_batchDetail", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web_1_1MainResource.html#a74d73ce9ae6b2ca83a048a56fa1bdf13", null ]
];