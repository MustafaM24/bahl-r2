var classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto =
[
    [ "BatchShortDto", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a15f0ae36a4c38c5d2abbbc3bfaaf63fd", null ],
    [ "BatchShortDto", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a0ef6347fb941d27ed06b4a1d2eef7055", null ],
    [ "columns", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a341af01cf2f7bf6ffd4e536c190a696c", null ],
    [ "getinputColumn", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a6e540440efcc8c95e339f074cee82166", null ],
    [ "getinputColumnValue", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a22b241e6221357361e76bc87189dca98", null ],
    [ "getOutputList", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a778e772922cdba848280d5277ede2792", null ],
    [ "setinputColumn", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a8e9877fc21041c575699150f98b2a1cf", null ],
    [ "setinputColumnValue", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a571d5dc6a011e497506cebf937fa0bb9", null ],
    [ "setOutputList", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a8a10c747bf0547b6d4def858960801ee", null ],
    [ "values", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a8d26ed9e4266688bd8c1b3224461e4d1", null ]
];