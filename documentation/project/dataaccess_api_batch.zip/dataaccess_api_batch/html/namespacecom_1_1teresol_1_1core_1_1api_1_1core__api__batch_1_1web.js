var namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web =
[
    [ "MainResource", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web_1_1MainResource.html", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web_1_1MainResource" ]
];