var classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto =
[
    [ "BatchDto", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#aa79aab04ad8d79836d36e60e65043905", null ],
    [ "BatchDto", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#ab8aca1b3113b83daec121d3afbd8200a", null ],
    [ "columns", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a00c7763af15b7f8548212cd623a20c1c", null ],
    [ "getinputColumn", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a7cb37e140ddbc034c2749744d01e587b", null ],
    [ "getinputColumnValue", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a792271d5aaec4cc0a0c71fde35a813dc", null ],
    [ "getOutputList", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a472c89bf0f4f7cc156047572045f5d43", null ],
    [ "setinputColumn", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#af46e2a6e8e3fdeee62ab1ad35850260e", null ],
    [ "setinputColumnValue", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a3c1a3cf7864016029874f0b1fef54e2d", null ],
    [ "setOutputList", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#adcaddbc50b851a87b2a872fc87430c9a", null ],
    [ "values", "classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a820139f2d68102ccd4d1d202527d890c", null ]
];