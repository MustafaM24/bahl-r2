var searchData=
[
  ['da_5fbatchdetail_43',['da_batchDetail',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1web_1_1MainResource.html#aa3b9a5c691021e0a8c6c05ef096ebc15',1,'com::teresol::dataaccess::api::dataaccess_api_batch::web::MainResource']]]
];
