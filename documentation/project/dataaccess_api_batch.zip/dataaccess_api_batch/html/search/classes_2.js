var searchData=
[
  ['mainbatchservice_29',['MainBatchService',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1services_1_1MainBatchService.html',1,'com::teresol::dataaccess::api::dataaccess_api_batch::services']]],
  ['mainresource_30',['MainResource',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1web_1_1MainResource.html',1,'com::teresol::dataaccess::api::dataaccess_api_batch::web']]]
];
