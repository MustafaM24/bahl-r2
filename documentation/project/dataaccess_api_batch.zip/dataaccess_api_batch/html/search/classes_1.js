var searchData=
[
  ['listnotequalexception_28',['ListNotEqualException',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1exceptions_1_1ListNotEqualException.html',1,'com::teresol::dataaccess::api::dataaccess_api_batch::exceptions']]]
];
