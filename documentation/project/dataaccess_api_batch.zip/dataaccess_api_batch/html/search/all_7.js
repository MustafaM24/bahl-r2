var searchData=
[
  ['querybuilder_20',['queryBuilder',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1querystores_1_1batchtlqueries_1_1BatchTlQuery.html#a3309e5b492891e58407c2325a238ad10',1,'com::teresol::dataaccess::api::dataaccess_api_batch::querystores::batchtlqueries::BatchTlQuery']]]
];
