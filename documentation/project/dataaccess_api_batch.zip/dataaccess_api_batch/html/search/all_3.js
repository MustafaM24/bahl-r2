var searchData=
[
  ['fnbatchdetails_15',['fnBatchDetails',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1services_1_1MainBatchService.html#a81ac835dc60189f24f14733d906d983d',1,'com::teresol::dataaccess::api::dataaccess_api_batch::services::MainBatchService']]]
];
