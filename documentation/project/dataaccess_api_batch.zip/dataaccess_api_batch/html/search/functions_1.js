var searchData=
[
  ['columns_42',['columns',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a00c7763af15b7f8548212cd623a20c1c',1,'com.teresol.dataaccess.api.dataaccess_api_batch.dto.BatchDto.columns()'],['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a341af01cf2f7bf6ffd4e536c190a696c',1,'com.teresol.dataaccess.api.dataaccess_api_batch.dto.BatchShortDto.columns()']]]
];
