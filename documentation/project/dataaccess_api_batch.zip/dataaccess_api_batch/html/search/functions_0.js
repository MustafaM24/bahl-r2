var searchData=
[
  ['batchdto_40',['BatchDto',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#aa79aab04ad8d79836d36e60e65043905',1,'com::teresol::dataaccess::api::dataaccess_api_batch::dto::BatchDto']]],
  ['batchshortdto_41',['BatchShortDto',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a15f0ae36a4c38c5d2abbbc3bfaaf63fd',1,'com::teresol::dataaccess::api::dataaccess_api_batch::dto::BatchShortDto']]]
];
