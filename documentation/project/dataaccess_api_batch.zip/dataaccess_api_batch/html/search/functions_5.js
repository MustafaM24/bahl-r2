var searchData=
[
  ['values_46',['values',['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchDto.html#a820139f2d68102ccd4d1d202527d890c',1,'com.teresol.dataaccess.api.dataaccess_api_batch.dto.BatchDto.values()'],['../classcom_1_1teresol_1_1dataaccess_1_1api_1_1dataaccess__api__batch_1_1dto_1_1BatchShortDto.html#a8d26ed9e4266688bd8c1b3224461e4d1',1,'com.teresol.dataaccess.api.dataaccess_api_batch.dto.BatchShortDto.values()']]]
];
