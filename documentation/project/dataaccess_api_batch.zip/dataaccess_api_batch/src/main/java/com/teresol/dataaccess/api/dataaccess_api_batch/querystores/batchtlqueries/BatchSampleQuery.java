/*! \brief This folder contains sub-folders according to the names of the table of database.
 *         
 *
 *  Detailed description starts here.
 */
package com.teresol.dataaccess.api.dataaccess_api_batch.querystores.batchtlqueries;

public class BatchSampleQuery {
    public String fetchBatchNoBatchStatus(){
        return "SELECT BATCH_NO, BAT_STS FROM BATCH_TL WHERE USER_ID=3 AND BRN_CD=111 AND BAT_STS=O";
    }
    public String fetchBatchNoBatchStatusbyUserIdBrnCd(){
        return "SELECT BATCH_NO, BAT_STS FROM BATCH_TL WHERE USER_ID=3 AND BRN_CD=111";
    }
}
