/**
* This is Batch Class for DTO of batch_tl table with constructors & get/set method
* Service Names: Batch.java
* Calling Classes: BatchService.java & Batch.java
* @author      Dayyan Satti, Azhar Hussain
* @version     1.1
* @return      List
*/

package com.teresol.dataaccess.api.dataaccess_api_batch.dto;
/**
* import libraries:
* java.util.ArrayList: is used for managing Arraylists
* java.util.List: to manage lists of type string
*/
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;

/** declaration of batch class */
@ApplicationScoped
public class BatchShortDto{
    /** declaration of class variables */
    private List<String> outputList;
    private List<String> inputColumn;
    private List<String> inputColumnValue;

    /** declaration of columns of batch_tl */
    public List<String> columns(){
        List<String> columns=new ArrayList<>();
        columns.add("batch_no");
        columns.add("bat_sts");
        columns.add("user_id");
        columns.add("dr_amt");
        columns.add("cr_amt");
        columns.add("no_of_tr");
        columns.add("no_sp_tr");
        columns.add("dept_no");
        columns.add("brn_cd");
        columns.add("no_au_tr");
        columns.add("loceq_dr");
        columns.add("loceq_cr");
        columns.add("batch_dt");
        columns.add("closed_by");
        columns.add("closed_dt");
        columns.add("closed_time");
        columns.add("user_ipaddr");
        columns.add("sub_brn_cd"); 
        return columns;
    }

    /** declaration of values against columns */
    public List<String> values(){
        List<String> values=new ArrayList<>();
        for (int i=0;i<columns().size();i++){
            values.add(null);
        }
        return values;
    }
 
     /** generation of constructors and getters/setters */
     public BatchShortDto(List<String> outputList, List<String> inputColumn, List<String> inputColumnValue) {
         this.outputList = outputList;
         this.inputColumn = inputColumn;
         this.inputColumnValue = inputColumnValue;
     }
     public BatchShortDto() {
     }
     public List<String> getOutputList() {
         return outputList;
     }
     public void setOutputList(List<String> outputList) {
         this.outputList = outputList;
     }
     public List<String> getinputColumn() {
         return inputColumn;
     }
     public void setinputColumn(List<String> inputColumn) {
         this.inputColumn = inputColumn;
     }
     public List<String> getinputColumnValue() {
         return inputColumnValue;
     }
     public void setinputColumnValue(List<String> inputColumnValue) {
         this.inputColumnValue = inputColumnValue;
     }
}
