package com.teresol.dataaccess.api.dataaccess_api_batch.querystores.batchtlqueries;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class BatchTlQuery {
    public String queryBuilder(List<String> outputList, List<String> inputColumn, List<String> inputColumnValue)
    {
        /**Dynamic Query building process start */
        /**The input string lists are traversed and concatenated in the SELECT and WHERE clause if they exist in the the input lists to form a complete executable query. */
        String query=null;
        String queryInput="WHERE ";
        String queryOutput="SELECT ";
        if(outputList.contains("select_all"))
        {
            queryOutput+="*";
        }
        else
        {
            for(int i=0;i<outputList.size();i++)
            {
                if(queryOutput.length()!=7&&outputList.get(i)!=null)
                {
                    queryOutput+=", ";
                }
                if(outputList.get(i)!=null)
                {
                    queryOutput+=outputList.get(i);
                }
            }
        }
        for(int i=0;i<inputColumn.size();i++)
        {
            if(queryInput.length()!=6&&inputColumnValue.get(i)!=null)
            {
                queryInput+=" AND ";
            }
            if(inputColumnValue.get(i)!=null)
            {
                queryInput+=inputColumn.get(i)+"='"+inputColumnValue.get(i)+"'";
            }
        }
        if(!inputColumn.isEmpty()){
            query=queryOutput+" FROM BATCH_TL "+queryInput;
        }
        else{
            query=queryOutput+" FROM BATCH_TL";
        }
        /**Dynamic Query bulding process end*/
        
        return query;
    }
}
