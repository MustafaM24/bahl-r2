
/**
* This is the main DA class to build connection, generate query, execute query and return its resultset.
* Service Names: BatchDA.java
* Building Quries based on input from MainResource.Java.
* @author      Dayyan Satti, Azhar Hussain
* @version     1.1
* @param  url  http://localhost:9081/batchDA/batchpost
* @return      Final Resultset in form of JSonArray.
*/
/*! \brief This folder has the java class in which the data access logic for this microservice
is implemented.
 *
 *  Detailed description starts here.
 */
package com.teresol.dataaccess.api.dataaccess_api_batch.services;

/**  
* import libraries and classes: 
* java.sql.Connection: to build connection to database
* java.sql.ResultSet: to store resultset of the executed database query
* java.sql.SQLException: to throw SQL related exceptions being generated from the DA layer
* java.sql.Statement: objeect used for executing a SQL statement and returning a resultset
* java.util.List: to manage three lists of type string
* javax.inject.Inject: to use injection of BatchCore class in this class
* javax.enterprise.context.ApplicationScoped: to initiate a single instance of the class to be used by whole application by just injecting the class
* com.ibm.db2.cmx.internal.json4j.JSONArray: to return JSON array of resultset
* com.ibm.db2.cmx.internal.json4j.JSONObject: to add Json object to JSON array
* org.jboss.logging.Logger: to write logs when required
* java.sql.ResultSetMetaData: used to get information about types and properties of columns in a resultset
* io.agroal.api.AgroalDataSource: to use datasource object for retrieving data
*/

import com.ibm.db2.cmx.internal.json4j.JSONArray;
import com.ibm.db2.cmx.internal.json4j.JSONObject;
import com.teresol.dataaccess.api.dataaccess_api_batch.querystores.batchtlqueries.BatchTlQuery;
import io.agroal.api.AgroalDataSource;
import io.quarkus.agroal.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import org.jboss.logging.Logger;






/**Declaration as ApplicationScoped of BatchDA */
@ApplicationScoped
public class MainBatchService {
    
    // @Inject
    // @DataSource("box1")
    // AgroalDataSource box1DataSource;
    @Inject
    @DataSource("box2")
    AgroalDataSource box2DataSource;
    // @Inject
    // @DataSource("box3")
    // AgroalDataSource box3DataSource;
    // @Inject
    // @DataSource("box4")
    // AgroalDataSource box4DataSource;
    
    @Inject
    BatchTlQuery batchTlQuery;
    /**Logger object declaration*/
    @Inject
    Logger logger;
    
    /**Method to establish connection with db, build query and return resultset*/
    public JSONArray fnBatchDetails(List<String> outputList, List<String> inputColumn, List<String> inputColumnValue) throws SQLException{
        
        String query=batchTlQuery.queryBuilder(outputList,inputColumn,inputColumnValue);
        try(Connection connection = box2DataSource.getConnection();
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(query);) {
            /**Query execution and and passing the the resultset into JSON array by using the metadata of resultset */
            logger.info("Executing query: " + query);
            JSONArray json = new JSONArray();
            int numColumns = rs.getMetaData().getColumnCount();
            while(rs.next()) {
                JSONObject obj = new JSONObject();
                for (int i=0; i<numColumns; i++) {
                    if(outputList.contains("select_all")){
                        String column_name = rs.getMetaData().getColumnName(i+1);
                        obj.put(column_name, rs.getString(i+1));
                    }
                    else{
                        obj.put(outputList.get(i), rs.getString(i+1));
                    }
                }
                json.add(obj);
            }
            return json;
        } catch (SQLException connectionException) {
            logger.error("Error in connection", connectionException);
            connectionException.printStackTrace();
        }
        return new JSONArray();
    }
}
