// package com.teresol.dataaccess.api.dataaccess_api_batch.connection;

// import java.sql.Connection;
// import java.sql.PreparedStatement;
// import java.sql.ResultSet;
// import java.sql.SQLException;
// import java.util.HashMap;
// import java.util.Map;

// import javax.enterprise.context.ApplicationScoped;
// import javax.inject.Inject;
// import javax.inject.Named;

// import io.agroal.api.AgroalDataSource;
// import io.quarkus.agroal.DataSource;
// import io.quarkus.arc.Unremovable;
// import io.quarkus.credentials.CredentialsProvider;
// import org.jboss.logging.Logger;

// @ApplicationScoped
// @Unremovable
// @Named("box1-credential-provider")
// public class Box1CredentialProvider implements CredentialsProvider{

//     @Inject
//     @DataSource("box1-appuser")
//     AgroalDataSource box1AppUserDataSource;
    
//     @Inject
//     Logger logger;
    
//     @Override
//     public Map<String, String> getCredentials(String credentialsProviderName) {
//         try(Connection con = box1AppUserDataSource.getConnection();
//         PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM APPUSER.CONNECTION_TL ct2 ");
//         ResultSet rest = preparedStatement.executeQuery();) {
//             Map<String, String> properties = new HashMap<>();
//             if(rest.next()){
//                 properties.put(USER_PROPERTY_NAME, rest.getString("USER_ID"));
//                 properties.put(PASSWORD_PROPERTY_NAME,PasswordDecrypter.getDecryptPsw(rest.getString("USER_ID"),rest.getString("PASSWORD")).toLowerCase());  
//             }
//             logger.info("Username: "+ properties.get(USER_PROPERTY_NAME));
//             logger.info("PASSWORD_PROPERTY_NAME: "+properties.get(PASSWORD_PROPERTY_NAME));
//             return properties;
//         } catch (SQLException e) {
//             e.printStackTrace();
//         }
//         return null;
//     }
// }
