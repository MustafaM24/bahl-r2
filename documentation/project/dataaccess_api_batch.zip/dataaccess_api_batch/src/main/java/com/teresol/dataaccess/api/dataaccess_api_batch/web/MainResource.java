/*! \brief This folder has the main class that has all the exported http endpoints from this service.
 *
 * 
 */
package com.teresol.dataaccess.api.dataaccess_api_batch.web;
/**
* This is main Class for calling BatchDA with seperate input and output parts of the query
* Service Names: BatchDetails
* Calling Classes: BatchDA.java & Batch.java
* @author      Dayyan Satti, Azhar Hussain
* @version     1.1
* @param  url  http://localhost:9081/batchDA/batchpost
* @return      Final Resultset in form of JSonArray.
*/


/**  
* import libraries and classes: 
* java.sql.SQLException: to throw SQL related exceptions being generated from the BatchDA.java
* java.util.List: Manage lists being passed as arguments
* javax.inject.Inject: to use injection of BatchCore class in this class
* javax.ws.rs.POST: to declare POST type request
* javax.ws.rs.Path: to declare of path of class or method
* javax.ws.rs.Produces: annotates that the method produces an output
* javax.ws.rs.core.MediaType: describes the type of output
* com.ibm.db2.cmx.internal.json4j.JSONArray: to use Json array functionality
* org.jboss.logging.Logger: to write logs when required
* BatchCore.BatchCore: to use an object for calling BatchCore method
* DTO.BatchListDTO: to use an object to recieve in dynamic method as parameter
* resource.BatchDA: to use batchDA object to call BatchDA method
*/

import com.ibm.db2.cmx.internal.json4j.JSONArray;
import com.teresol.dataaccess.api.dataaccess_api_batch.dto.BatchDto;
import com.teresol.dataaccess.api.dataaccess_api_batch.services.MainBatchService;
import java.sql.SQLException;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.jboss.logging.Logger;


/**Path declaration for method*/
@Path("/dataaccess_api_batch")
public class MainResource {
  /**Injection and declaration of Logger object*/
  @Inject
  Logger logger;
  /**Injection and declaration of BatchDA object*/
  @Inject
  MainBatchService batchDA;
  
  /**Request type and path declaration and type of output produced for method*/
  @GET
  @Path("/da_batchDetail")
  @Produces(MediaType.APPLICATION_JSON)
  public JSONArray da_batchDetail(BatchDto bDto) throws SQLException  
  { 
    return batchDA.fnBatchDetails(bDto.getOutputList(),bDto.getinputColumn(),bDto.getinputColumnValue());
  }
}
