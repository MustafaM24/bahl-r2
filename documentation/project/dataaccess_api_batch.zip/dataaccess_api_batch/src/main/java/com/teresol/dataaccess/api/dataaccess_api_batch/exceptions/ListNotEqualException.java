/*! \brief This folder holds all custom exceptions that this service will use.
 *        
 *
 *  Detailed description starts here.
 */
package com.teresol.dataaccess.api.dataaccess_api_batch.exceptions;

public class ListNotEqualException extends Exception {  
    public ListNotEqualException(String errorMessage) {  
    super(errorMessage);  
    }  
}  
