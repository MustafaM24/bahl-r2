var namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto =
[
    [ "BatchDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto" ],
    [ "BatchShortDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto" ]
];