var annotated_dup =
[
    [ "com", null, [
      [ "teresol", null, [
        [ "core", null, [
          [ "api", null, [
            [ "core_api_batch", null, [
              [ "dto", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto.html", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto" ],
              [ "exceptions", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1exceptions.html", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1exceptions" ],
              [ "services", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1services.html", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1services" ],
              [ "util", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1util.html", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1util" ],
              [ "web", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web.html", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web" ],
              [ "webclient", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1webclient.html", "namespacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1webclient" ]
            ] ]
          ] ]
        ] ]
      ] ]
    ] ]
];