var searchData=
[
  ['values_19',['values',['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a97987e60541175de4839e08090725a4a',1,'com.teresol.core.api.core_api_batch.dto.BatchDto.values()'],['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a53f00f2bf9e79346b89e3a4afe83ea56',1,'com.teresol.core.api.core_api_batch.dto.BatchShortDto.values()']]]
];
