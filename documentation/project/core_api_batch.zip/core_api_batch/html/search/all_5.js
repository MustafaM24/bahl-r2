var searchData=
[
  ['mainbatchservice_16',['MainBatchService',['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1services_1_1MainBatchService.html',1,'com::teresol::core::api::core_api_batch::services']]],
  ['mainresource_17',['MainResource',['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web_1_1MainResource.html',1,'com::teresol::core::api::core_api_batch::web']]]
];
