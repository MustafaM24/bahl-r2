var searchData=
[
  ['columns_36',['columns',['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#ad95951ca3c1ad3da23686d954fb286b1',1,'com.teresol.core.api.core_api_batch.dto.BatchDto.columns()'],['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a700f501e1415292b3cc02882b6f91903',1,'com.teresol.core.api.core_api_batch.dto.BatchShortDto.columns()']]]
];
