var searchData=
[
  ['batch_2dcore_20project_41',['batch-core Project',['../md_README.html',1,'']]]
];
