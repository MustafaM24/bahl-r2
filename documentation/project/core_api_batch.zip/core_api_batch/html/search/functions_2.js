var searchData=
[
  ['da_5fbatchdetail_37',['da_batchDetail',['../interfacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1webclient_1_1DataaccessApiBatch.html#abe273975ddab84bc8c53c7cef369419d',1,'com::teresol::core::api::core_api_batch::webclient::DataaccessApiBatch']]]
];
