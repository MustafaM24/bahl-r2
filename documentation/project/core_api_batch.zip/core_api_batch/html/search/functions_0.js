var searchData=
[
  ['batchdto_34',['BatchDto',['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a80113ed4ad675d28972e0fac2f04707c',1,'com::teresol::core::api::core_api_batch::dto::BatchDto']]],
  ['batchshortdto_35',['BatchShortDto',['../classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html#a00e68449cce81bd68a049312a6329490',1,'com::teresol::core::api::core_api_batch::dto::BatchShortDto']]]
];
