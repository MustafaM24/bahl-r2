var classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto =
[
    [ "BatchDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a80113ed4ad675d28972e0fac2f04707c", null ],
    [ "BatchDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a7d8b6ac8ca24b3c2d5f697e8cae1eb06", null ],
    [ "columns", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#ad95951ca3c1ad3da23686d954fb286b1", null ],
    [ "getinputColumn", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a8ac69c75ea299a4e0e8078ad553d30a9", null ],
    [ "getinputColumnValue", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a2828d976c531b01c0c4e94b6c71c7158", null ],
    [ "getOutputList", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a11eec9b90107dacb948e147a6a9cba9e", null ],
    [ "setinputColumn", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a59d1335d5d80dbeba39b54d7fd9bfe27", null ],
    [ "setinputColumnValue", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#ada2663e34b167daac56f912e5c22b2e9", null ],
    [ "setOutputList", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#ac175dced8120ac24b461d7441901aa90", null ],
    [ "values", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html#a97987e60541175de4839e08090725a4a", null ]
];