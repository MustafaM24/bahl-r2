var hierarchy =
[
    [ "com.teresol.core.api.core_api_batch.dto.BatchDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchDto.html", null ],
    [ "com.teresol.core.api.core_api_batch.dto.BatchShortDto", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1dto_1_1BatchShortDto.html", null ],
    [ "com.teresol.core.api.core_api_batch.webclient.DataaccessApiBatch", "interfacecom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1webclient_1_1DataaccessApiBatch.html", null ],
    [ "Exception", null, [
      [ "com.teresol.core.api.core_api_batch.exceptions.BatchExceptions", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1exceptions_1_1BatchExceptions.html", null ]
    ] ],
    [ "com.teresol.core.api.core_api_batch.services.MainBatchService", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1services_1_1MainBatchService.html", null ],
    [ "com.teresol.core.api.core_api_batch.web.MainResource", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1web_1_1MainResource.html", null ],
    [ "com.teresol.core.api.core_api_batch.util.Utility", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1util_1_1Utility.html", null ],
    [ "RestClientBuilderListener", null, [
      [ "com.teresol.core.api.core_api_batch.webclient.CustomRestClientBuilderListener", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1webclient_1_1CustomRestClientBuilderListener.html", null ]
    ] ]
];