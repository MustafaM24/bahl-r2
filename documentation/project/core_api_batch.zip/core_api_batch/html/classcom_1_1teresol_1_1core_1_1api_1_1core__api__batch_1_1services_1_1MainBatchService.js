var classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1services_1_1MainBatchService =
[
    [ "fnBatchDetails", "classcom_1_1teresol_1_1core_1_1api_1_1core__api__batch_1_1services_1_1MainBatchService.html#a6c6bd541335cd8d97c9691f5b5f6e271", null ]
];