/*! \brief This folder holds all custom exceptions that this service will use.
 *
 * 
 */
package com.teresol.core.api.core_api_batch.exceptions;

public class BatchExceptions extends Exception {  
    public BatchExceptions(String errorMessage) {  
    super(errorMessage);  
    }  
}  
