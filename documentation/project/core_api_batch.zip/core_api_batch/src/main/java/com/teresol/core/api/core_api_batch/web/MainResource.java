/*! \brief This folder has the main class that has all the exported http endpoints from this service.
 *
 * 
 */
package com.teresol.core.api.core_api_batch.web;


/**
* This is Class-Zero (Initiator) for recieving end-point Inputs via URL; passing further to Core's DTO creation and DA access.
* Service Names: MainResource.java
* Calling Classes: BatchCore.java
* @author      Dayyan Satti, Azhar Hussain
* @version     1.1
* @param  url  http://localhost:9080/batch-core/dynamic/
* @return      Final Resultset in form of JSonArray.
*/

/**  
* import libraries and classes: 
* java.util.List: Manage lists being passed as arguments
* javax.inject.Inject: Defines injection of BatchCore object instance in this class
* javax.ws.rs.FormParam:to take FormParams as input parameters in function
* javax.ws.rs.POST: to declare POST type request
* javax.ws.rs.Path: to declare path of class or method
* io.vertx.core.json.JsonArray: to use Json array functionality
* org.jboss.logging.Logger: to write logs when required
* BatchCore.BatchCore: to use an object for calling BatchCore class method
*/

import com.teresol.core.api.core_api_batch.services.MainBatchService;
import io.vertx.core.json.JsonArray;
import java.util.List;
import javax.inject.Inject;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import org.jboss.logging.Logger;





/**Path declaration for MainResource class*/
@Path("/core_api_batch")
public class MainResource {

/**Logger object declaration*/
  Logger logger;

/**Injection and declaration of BatchCore object*/
  @Inject
  MainBatchService batchServiceObj;

/**Declaration of Request Type and path for method
 * -outputList: Holds columns & values to be retrieved from the database as string datatype
 * -inputColumn: Holds the column names against which the data has to be retrieved as string datatype
 * -inputColumnValue: Holds the column values against which the data has to be retrieved as string datatype
*/
  @GET
  @Path("/batchDetail")
  public JsonArray get_batchDetail(
  @FormParam("outputList") List<String> outputList,
  @FormParam("inputColumn") List<String> inputColumn,
  @FormParam("inputColumnValue") List<String> inputColumnValue
  )
  { 
/**fnBatchDetails function call by batchCore object*/
    return batchServiceObj.fnBatchDetails(outputList,inputColumn,inputColumnValue);
  }
}
