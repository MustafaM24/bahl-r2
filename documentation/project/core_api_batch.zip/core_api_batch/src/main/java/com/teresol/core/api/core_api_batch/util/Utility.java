/*! \brief This folder has the utility class in which the utility functions for this service are implemented.
 *
 * 
 */
package com.teresol.core.api.core_api_batch.util;

import java.util.List;

public class Utility {
    private Utility() { } //Prevent the class from being constructed
    
    public static boolean checkEquality(List<String> list1, List<String> list2){
        boolean bol=(list1.size()==list2.size()) ? true:false;
        return bol;
    }
}
