/**
* This is core class to assign values to DTO lists and pass onto BatchMain.java method
* Service Names: BatchCore.java
* Calling Classes: BatchMain.java & Batch.java
* @author      Dayyan Satti, Azhar Hussain
* @version     1.1
* @return      Final Resultset in form of JSonArray.
*/

/*! \brief This folder has the java class in which the core logic for this service is implemented
 *
 * 
 */
package com.teresol.core.api.core_api_batch.services;
/**  
* import libraries and classes: 
* java.util.List: Manage lists being passed as arguments
* javax.inject.Inject: Defines injection of BatchCore object instance in this class
* javax.enterprise.context.ApplicationScoped: to initiate a single instance of the class to be used by whole application by just injecting the class
* io.vertx.core.json.JsonArray: to use Json array functionality
* org.jboss.logging.Logger: to write logs when required
* org.eclipse.microprofile.rest.client.inject.RestClient: to use BatchMain as Rest Client
* DTO.Batch: to use an object for calling Batch method
* service.Batchmain: to use an object for calling BatchMain method
*/
import com.teresol.core.api.core_api_batch.dto.BatchDto;
import com.teresol.core.api.core_api_batch.util.Utility;
import com.teresol.core.api.core_api_batch.webclient.DataaccessApiBatch;
import io.vertx.core.json.JsonArray;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;





/**Declaration as ApplicationScoped of BatchCore */
@ApplicationScoped
public class MainBatchService {

/**Logger object declaration*/ 
@Inject
  Logger logger;

/**Declaration of Batch object*/
@Inject
  BatchDto batch;

/**Injection and declaration of Batchmain object as RestClient*/
  @Inject
  @RestClient
  DataaccessApiBatch dApiBatch;

  /**Method declared to implement core logic on input data and pass through interface object to method */
  public JsonArray fnBatchDetails(List<String> outputList, List<String> inputColumn,List<String> inputColumnValue)
  { 
    /**Injected batch object pass to interface method */
    if(Utility.checkEquality(inputColumn, inputColumnValue)){
      batch.setinputColumn(inputColumn);
      batch.setOutputList(outputList);
      batch.setinputColumnValue(inputColumnValue);
    }
    else{}
    return dApiBatch.da_batchDetail(batch);
  }     
}
