/**
* This is interface class to access DA layer/method with the same path/url.
* Service Names: BatchMain.java
* Calling Module: Data Access Layer
* @author      Dayyan Satti, Azhar Hussain
* @version     1.1
*/

/**  
* import libraries and classes: \n
* javax.ws.rs.POST: to declare POST type request
* javax.ws.rs.Path: to declare of path of class or method
* javax.ws.rs.Produces: annotates that the method produces an output
* javax.ws.rs.core.MediaType: describes the type of output
* io.vertx.core.json.JsonArray: to use Json array functionality
* org.eclipse.microprofile.rest.client.inject.RegisterRestClient: to Register BatchMain as Rest Client
* DTO.Batch: to use an object to pass in dynamic method as parameter
*/
package com.teresol.core.api.core_api_batch.webclient;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.teresol.core.api.core_api_batch.dto.BatchDto;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import io.vertx.core.json.JsonArray;

/**path declaration and registering as rest client declaration of class*/
@Path("/dataaccess_api_batch")
@RegisterRestClient
public interface DataaccessApiBatch {

    /**request type and path declaration and type of output produced for method*/
    @GET
    @Path("/da_batchDetail")
    @Produces(MediaType.APPLICATION_JSON)
    public JsonArray da_batchDetail(BatchDto bDto);
}
